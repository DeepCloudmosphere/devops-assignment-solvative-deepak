// index.js
const AWS = require("aws-sdk");
const s3 = new AWS.S3();
const tableName = process.env.METADATA_TABLE;
const bucket = process.env.MEDIA_BUCKET;

exports.handler = async (event) => {
  // For demo: read key from query string ?key=path/to/file.mp4
  const qs = event.queryStringParameters || {};
  const key = qs.key;
  if (!key) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing key parameter" }) };
  }

  // generate presigned GET url for short time (300s)
  const url = s3.getSignedUrl('getObject', {
    Bucket: bucket,
    Key: key,
    Expires: 300
  });

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url })
  };
};

